/**
 * SQNC - Immersive Presentation Application
 * Primary interactive deck with multilingual support and responsive navigation.
 */
import React, { useState, useEffect, createContext, useContext } from 'react';
import { motion } from 'motion/react';
import { ChevronDown, Globe, Eye, EyeOff, ChevronLeft, ChevronRight } from 'lucide-react';
import { translations, Language } from './locales';
import logoImg from './assets/logo.png';

import heroBg from './assets/images/0e6a77f2-8572-4fe3-8a94-adb09aa17782.jpg';
import conceptBg from './assets/images/147ced0e-04ae-489f-b7a7-b2829f1abf78.jpg';
import experienceBg from './assets/images/159e1c37-6149-4a2b-a8ba-ad1bb67a05f2.jpg';
import visitorBg from './assets/images/1d55d2dc-2ee8-48ad-ac3b-cb04831af6de.jpg';
import strategicBg from './assets/images/35f8a3ae-ff11-43e8-a6ea-cd79189cd3f0.jpg';
import investmentBg from './assets/images/724ebd8d-5972-464f-a7ac-23b46a34079f.jpg';
import revenueBg from './assets/images/779e737c-22b1-436f-9842-f51177acf487.jpg';
import sponsorsBg from './assets/images/996ee9e7-178b-40e9-aac9-266ade02c388.jpg';
import whyNowBg from './assets/images/b355d07d-61ac-4379-a489-d3339db8fe4b.jpg';

const IMAGES = {
  hero: heroBg,
  concept: conceptBg,
  experience: experienceBg,
  visitor: visitorBg,
  strategic: strategicBg,
  investment: investmentBg,
  revenue: revenueBg,
  sponsors: sponsorsBg,
  whyNow: whyNowBg
};

const ImmersiveContext = createContext(false);

const Section = ({ id, index, title, children, image }: { id: string, index: string, title?: string, children: React.ReactNode, image?: string }) => {
  const immersiveMode = useContext(ImmersiveContext);
  return (
  <section id={id} className="min-h-screen relative flex items-center py-24 px-6 md:px-12 lg:px-24 border-b border-white/5">
    {image && (
      <div className="absolute inset-0 z-0 overflow-hidden">
        <motion.img 
          initial={{ scale: 1.1 }}
          whileInView={{ scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          viewport={{ once: true }}
          src={image} 
          className="w-full h-full object-cover opacity-100 mix-blend-normal" 
        />
        <div className={`absolute inset-0 transition-colors duration-700 ${immersiveMode ? 'bg-charcoal/0' : 'bg-charcoal/50'}`}></div>
      </div>
    )}
    <div className={`relative z-10 w-full max-w-7xl mx-auto flex flex-col md:flex-row gap-12 lg:gap-24 transition-opacity duration-700 ${immersiveMode ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
      <div className="w-full md:w-1/3">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="sticky top-32"
        >
          <div className="text-accent-blue font-bold text-xl tracking-widest mb-4">{index}</div>
          {title && <h2 className="text-4xl md:text-5xl font-sans tracking-wide leading-tight">{title}</h2>}
        </motion.div>
      </div>
      <div className="w-full md:w-2/3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-charcoal/70 backdrop-blur-xl p-6 md:p-10 rounded-xl border border-white/10 shadow-2xl"
        >
          {children}
        </motion.div>
      </div>
    </div>
  </section>
)};

const ALL_IMAGES = Object.values(IMAGES);

const ImageGallery = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const next = () => setCurrentIndex((i) => (i + 1) % ALL_IMAGES.length);
  const prev = () => setCurrentIndex((i) => (i - 1 + ALL_IMAGES.length) % ALL_IMAGES.length);

  useEffect(() => {
    const timer = setInterval(() => {
      next();
    }, 15000);
    return () => clearInterval(timer);
  }, [currentIndex]);

  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      next();
    }
    if (isRightSwipe) {
      prev();
    }
  };

  return (
    <section 
      id="gallery" 
      className="relative w-full h-screen bg-charcoal overflow-hidden group"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      <div 
        className="absolute inset-0 flex transition-transform duration-700 ease-in-out" 
        style={{ transform: `translateX(-${currentIndex * 100}%)`}}
      >
        {ALL_IMAGES.map((img, idx) => (
          <div key={idx} className="w-full h-full flex-shrink-0 relative">
            <img src={img} className="w-full h-full object-cover" />
          </div>
        ))}
      </div>
      
      {/* Navigation Arrows */}
      <button 
        onClick={prev} 
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 p-3 md:p-4 bg-charcoal/50 hover:bg-charcoal/80 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10 border border-white/10"
      >
        <ChevronLeft className="w-6 h-6 md:w-8 md:h-8" />
      </button>
      <button 
        onClick={next} 
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 p-3 md:p-4 bg-charcoal/50 hover:bg-charcoal/80 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10 border border-white/10"
      >
        <ChevronRight className="w-6 h-6 md:w-8 md:h-8" />
      </button>
      
      {/* Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 z-10">
        {ALL_IMAGES.map((_, idx) => (
          <button 
            key={idx} 
            onClick={() => setCurrentIndex(idx)} 
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${currentIndex === idx ? 'bg-warm-white scale-125' : 'bg-warm-white/30 hover:bg-warm-white/50'}`} 
          />
        ))}
      </div>
    </section>
  );
};

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [showNavLogo, setShowNavLogo] = useState(false);
  const [lang, setLang] = useState<Language>('en');
  const [immersiveMode, setImmersiveMode] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      setShowNavLogo(window.scrollY > window.innerHeight * 0.7);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const t = translations[lang];

  return (
    <ImmersiveContext.Provider value={immersiveMode}>
    <div className="bg-charcoal text-warm-white selection:bg-accent-blue/30 font-sans font-light">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-700 ${isScrolled ? 'glass-panel py-4' : 'bg-transparent py-8'} ${immersiveMode ? 'opacity-0 pointer-events-none translate-y-[-100%]' : 'opacity-100 translate-y-0'}`}>
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
          <div className={`relative flex items-center transition-opacity duration-700 ${showNavLogo ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            {/* Logo image that uses mix-blend-screen to remove black background */}
            <img 
              src={logoImg} 
              alt="SQNC" 
              className="h-10 md:h-12 w-auto object-contain mix-blend-screen" 
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                document.getElementById('nav-text-logo')!.style.display = 'block';
              }} 
            />
            <div id="nav-text-logo" className="text-4xl tracking-normal font-display text-muted-gold hidden">
              SQNC
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="text-xs tracking-widest uppercase text-stone hidden md:block">
              {t.navSubtitle}
            </div>
            
            <div className="flex items-center gap-2 bg-charcoal/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 relative z-[100] cursor-pointer">
              <Globe className="w-3.5 h-3.5 text-stone" />
              <select 
                value={lang} 
                onChange={(e) => setLang(e.target.value as Language)}
                className="bg-transparent text-xs font-semibold uppercase text-warm-white outline-none cursor-pointer"
              >
                <option value="en" className="bg-charcoal text-warm-white">EN</option>
                <option value="es" className="bg-charcoal text-warm-white">ES</option>
                <option value="ru" className="bg-charcoal text-warm-white">RU</option>
              </select>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col justify-center px-6 md:px-12 lg:px-24 overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 z-0">
           <img 
            src={IMAGES.hero}
            alt="Mansion Interior"
            className="w-full h-full object-cover opacity-100 mix-blend-normal"
           />
           <div className={`absolute inset-0 transition-colors duration-700 ${immersiveMode ? 'bg-charcoal/0' : 'bg-charcoal/50'}`}></div>
        </div>
        
        <div className={`relative z-10 max-w-5xl mt-0 md:mt-8 lg:mt-12 transition-opacity duration-700 ${immersiveMode ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="mb-8 flex justify-start"
          >
            <img 
              src={logoImg} 
              alt="SQNC" 
              className="h-32 md:h-48 lg:h-64 w-auto object-contain mix-blend-screen -ml-10 md:-ml-20 lg:-ml-28 neon-flicker" 
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                document.getElementById('hero-text-logo')!.style.display = 'block';
              }} 
            />
            <h1 id="hero-text-logo" className="text-8xl md:text-9xl lg:text-[12rem] font-display tracking-normal text-muted-gold leading-none hidden">
              SQNC
            </h1>
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            <p className="text-xl md:text-3xl text-warm-white tracking-wide font-light max-w-3xl mb-4">
              {t.heroSubtitle}
            </p>
            <div className="h-px w-24 bg-accent-blue/50 my-8"></div>
            <p className="text-lg text-stone tracking-widest uppercase mb-2">
              {t.navSubtitle}
            </p>
            <p className="text-md text-stone/70">
              {t.heroLocation}
            </p>
          </motion.div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="absolute bottom-12 left-6 md:left-12 lg:left-24 animate-bounce text-stone"
        >
          <ChevronDown className="w-6 h-6" />
        </motion.div>
      </section>

      {/* 01 Project Concept */}
      <Section id="concept" index="01" title={t.conceptTitle} image={IMAGES.concept}>
        <div className="space-y-6 text-lg leading-relaxed text-stone">
          <p className="text-xl text-warm-white">{t.conceptDesc1}</p>
          <p>{t.conceptDesc2}</p>
          <p>{t.conceptDesc3}</p>
          
          <div className="pt-6">
            <p className="mb-4 text-warm-white">{t.conceptSubtitle}</p>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {t.conceptList.map((item, i) => (
                <li key={i} className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent-blue"></div>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          
          <p className="pt-6 text-muted-gold italic">{t.conceptQuote}</p>
        </div>
      </Section>

      {/* 02 Experience Format */}
      <Section id="format" index="02" title={t.formatTitle} image={IMAGES.experience}>
        <div className="space-y-6 text-lg leading-relaxed text-stone">
          <p className="text-xl text-warm-white">{t.formatDesc1}</p>
          
          <div className="pt-4">
            <p className="mb-6">{t.formatDesc2}</p>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {t.formatList.map((item, i) => (
                <li key={i} className="flex items-center gap-3 p-3 bg-charcoal/40 border border-white/5 rounded-sm">
                  <div className="w-1 h-4 bg-accent-blue/50"></div>
                  <span className="text-warm-white/90">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <p className="pt-6">{t.formatDesc3}</p>
        </div>
      </Section>

      {/* 03 Visitor Experience */}
      <Section id="visitor" index="03" title={t.visitorTitle} image={IMAGES.visitor}>
        <div className="space-y-12">
          {/* Top stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {t.visitorStats.map((stat, i) => (
              <div key={i} className="bg-charcoal/60 border border-white/10 p-6 rounded-sm text-center flex flex-col justify-center">
                <div className="text-xs uppercase tracking-widest text-stone mb-2">{stat.label}</div>
                <div className="text-sm font-semibold text-warm-white">{stat.value}</div>
              </div>
            ))}
          </div>

          <div>
            <h3 className="text-2xl text-muted-gold mb-6">{t.visitorProgression}</h3>
            <ul className="space-y-4 text-stone">
              {t.visitorStates.map((state, i) => (
                <li key={i} className="flex gap-4">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-accent-blue shrink-0"></div>
                  <div>
                    <span className="text-warm-white font-medium">{state.title}</span> <span className="opacity-50">—</span> {state.desc}
                  </div>
                </li>
              ))}
            </ul>
          </div>
          
          <p className="text-lg text-stone/90 border-l-2 border-accent-blue/50 pl-6 py-2">
            {t.visitorQuote}
          </p>
        </div>
      </Section>

      {/* 04 Strategic Value */}
      <Section id="value" index="04" title={t.valueTitle} image={IMAGES.strategic}>
        <div className="space-y-8 text-lg leading-relaxed text-stone">
          <p>{t.valueDesc1}</p>
          
          <div>
            <p className="mb-4 text-warm-white">{t.valueDesc2}</p>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {t.valueList.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <div className="mt-2 w-1.5 h-1.5 rounded-full bg-accent-blue shrink-0"></div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <p className="p-6 bg-white/5 border border-white/10 rounded-sm text-warm-white">
            {t.valueQuote}
          </p>
        </div>
      </Section>

      {/* 05 CAPEX */}
      <Section id="capex" index="05" title={t.capexTitle} image={IMAGES.investment}>
        <div className="bg-charcoal/80 border border-white/10 rounded-sm overflow-hidden shadow-2xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/5 border-b border-white/10 text-xs uppercase tracking-widest text-stone">
                <th className="p-4 font-normal">{t.capexCategory}</th>
                <th className="p-4 font-normal text-right">{t.capexEstimate}</th>
              </tr>
            </thead>
            <tbody className="text-warm-white divide-y divide-white/5">
              {t.capexRows.map((row, i) => (
                <tr key={i} className="hover:bg-white/5 transition-colors">
                  <td className="p-4 text-stone">{row.cat}</td>
                  <td className="p-4 text-right">{row.est}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="p-6 bg-muted-gold/10 border-t border-muted-gold/20 flex justify-between items-center">
            <span className="font-semibold text-muted-gold">{t.capexTotal}</span>
            <span className="text-xl font-bold text-muted-gold">{t.capexTotalValue}</span>
          </div>
        </div>
      </Section>

      {/* 06 OPEX */}
      <Section id="opex" index="06" title={t.opexTitle}>
        <div className="bg-charcoal/80 border border-white/10 rounded-sm overflow-hidden shadow-2xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/5 border-b border-white/10 text-xs uppercase tracking-widest text-stone">
                <th className="p-4 font-normal">{t.opexCategory}</th>
                <th className="p-4 font-normal text-right">{t.opexEstimate}</th>
              </tr>
            </thead>
            <tbody className="text-warm-white divide-y divide-white/5">
              {t.opexRows.map((row, i) => (
                <tr key={i} className="hover:bg-white/5 transition-colors">
                  <td className="p-4 text-stone">{row.cat}</td>
                  <td className="p-4 text-right">{row.est}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="p-6 bg-accent-blue/10 border-t border-accent-blue/20 flex justify-between items-center">
            <span className="font-semibold text-accent-blue">{t.opexTotal}</span>
            <span className="text-xl font-bold text-accent-blue">{t.opexTotalValue}</span>
          </div>
        </div>
      </Section>

      {/* 07 Revenue Model */}
      <Section id="revenue" index="07" title={t.revenueTitle} image={IMAGES.revenue}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          <div className="bg-charcoal/60 border border-white/10 p-8 rounded-sm shadow-xl backdrop-blur-sm">
            <div className="text-stone mb-2 uppercase tracking-wider text-sm">{t.revenueTicket}</div>
            <div className="text-4xl font-semibold text-muted-gold mb-4">{t.revenueTicketValue}</div>
          </div>
          
          <div className="space-y-6">
            <div className="bg-charcoal/60 border border-white/10 p-6 rounded-sm shadow-xl backdrop-blur-sm flex flex-col sm:flex-row justify-between sm:items-center gap-4">
              <div>
                <div className="font-semibold text-warm-white mb-1">{t.revenuePrivate}</div>
                <div className="text-sm text-stone">{t.revenuePrivateDesc}</div>
              </div>
              <div className="text-xl text-accent-blue font-semibold text-right">{t.revenuePrivateValue}</div>
            </div>
            
            <div className="bg-charcoal/60 border border-white/10 p-6 rounded-sm shadow-xl backdrop-blur-sm flex flex-col sm:flex-row justify-between sm:items-center gap-4">
              <div>
                <div className="font-semibold text-warm-white mb-1">{t.revenueCorp}</div>
                <div className="text-sm text-stone">{t.revenueCorpDesc}</div>
              </div>
              <div className="text-xl text-accent-blue font-semibold text-right">{t.revenueCorpValue}</div>
            </div>
          </div>
        </div>
      </Section>

      {/* 08 Revenue Potential */}
      <Section id="potential" index="08" title={t.potentialTitle}>
        <div className="space-y-6 mb-12">
          <div className="bg-charcoal/60 border border-white/10 p-8 rounded-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
            <div>
              <div className="text-xl font-semibold text-warm-white mb-2">{t.potentialCons}</div>
              <div className="text-stone">{t.potentialConsDesc}</div>
            </div>
            <div className="text-2xl font-bold text-emerald-400">{t.potentialConsValue}</div>
          </div>
          
          <div className="bg-charcoal/60 border border-white/10 p-8 rounded-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
            <div>
              <div className="text-xl font-semibold text-warm-white mb-2">{t.potentialBase}</div>
              <div className="text-stone">{t.potentialBaseDesc}</div>
            </div>
            <div className="text-2xl font-bold text-emerald-400">{t.potentialBaseValue}</div>
          </div>
        </div>

        <div className="bg-white/5 p-8 border-l-4 border-muted-gold rounded-r-sm">
          <h3 className="text-xl font-semibold text-muted-gold mb-4">{t.potentialAdd}</h3>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
            {t.potentialAddList.map((item, i) => (
              <li key={i} className="flex items-center gap-3 text-stone">
                <div className="w-1.5 h-1.5 rounded-full bg-accent-blue"></div>
                {item}
              </li>
            ))}
          </ul>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 sm:items-center">
            <span className="font-semibold text-warm-white text-lg">{t.potentialTotal}</span>
            <span className="text-2xl font-bold text-muted-gold">{t.potentialTotalValue}</span>
          </div>
        </div>
      </Section>

      {/* 09 ROI */}
      <Section id="roi" index="09" title={t.roiTitle}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-charcoal/60 border border-white/10 p-8 rounded-sm space-y-8 shadow-xl">
            <h3 className="text-2xl font-semibold text-muted-gold mb-6 pb-6 border-b border-white/10">{t.roiNoSponsors}</h3>
            <div>
              <div className="text-sm text-stone mb-1 uppercase tracking-wider">{t.roiInvest}</div>
              <div className="text-xl font-bold text-warm-white">{t.roiInvestValue1}</div>
            </div>
            <div>
              <div className="text-sm text-stone mb-1 uppercase tracking-wider">{t.roiProfit}</div>
              <div className="text-xl font-bold text-warm-white">{t.roiProfitValue}</div>
            </div>
            <div>
              <div className="text-sm text-stone mb-1 uppercase tracking-wider">{t.roiPayback}</div>
              <div className="text-xl font-bold text-warm-white">{t.roiPaybackValue}</div>
            </div>
          </div>
          
          <div className="bg-charcoal/60 border border-accent-blue/20 p-8 rounded-sm space-y-8 relative overflow-hidden shadow-xl">
            <div className="absolute top-0 right-0 w-32 h-32 bg-accent-blue/10 blur-3xl rounded-full"></div>
            <h3 className="text-2xl font-semibold text-accent-blue mb-6 pb-6 border-b border-white/10 relative z-10">{t.roiSponsors}</h3>
            <div className="relative z-10">
              <div className="text-sm text-stone mb-1 uppercase tracking-wider">{t.roiOwnerInvest}</div>
              <div className="text-xl font-bold text-warm-white">{t.roiOwnerInvestValue}</div>
            </div>
            <div className="relative z-10">
              <div className="text-sm text-stone mb-1 uppercase tracking-wider">{t.roiPath}</div>
              <div className="text-xl font-bold text-warm-white">{t.roiPathValue}</div>
            </div>
          </div>
        </div>
      </Section>

      {/* 10 Sponsorship */}
      <Section id="sponsorship" index="10" title={t.sponsorsTitle} image={IMAGES.sponsors}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t.sponsorsTiers.map((tier, i) => (
            <div key={i} className="bg-charcoal/80 backdrop-blur-md border border-white/10 p-6 rounded-sm flex flex-col shadow-xl hover:border-white/20 transition-colors">
              <h4 className="text-xl font-semibold text-warm-white mb-2">{tier.title}</h4>
              <div className="text-xs text-stone mb-6 pb-4 border-b border-white/10 uppercase tracking-wide">{tier.target}</div>
              <div className="text-2xl font-bold text-muted-gold mb-6">{tier.value}</div>
              <ul className="space-y-3 mt-auto">
                {tier.items.map((item, j) => (
                  <li key={j} className="text-sm text-stone flex items-start gap-2">
                    <div className="mt-1.5 w-1 h-1 rounded-full bg-accent-blue shrink-0"></div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* 11 Why SQNC Now */}
      <Section id="whynow" index="11" title={t.whynowTitle} image={IMAGES.whyNow}>
        <div className="space-y-8 text-lg leading-relaxed text-stone">
          <p>{t.whynowDesc1}</p>
          
          <div>
            <p className="mb-4 text-warm-white">{t.whynowDesc2}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {t.whynowList.map((item, i) => (
                <div key={i} className="bg-white/5 border border-white/10 py-4 px-2 text-center text-sm text-warm-white/70 rounded-sm">
                  {item}
                </div>
              ))}
            </div>
          </div>
          
          <p className="text-xl text-warm-white">{t.whynowDesc3}</p>
          
          <p className="p-6 border-l-4 border-muted-gold bg-muted-gold/5 text-warm-white rounded-r-sm">
            {t.whynowQuote}
          </p>
        </div>
      </Section>

      <ImageGallery />

      {/* Footer */}
      <footer className={`py-12 border-t border-white/10 text-center text-sm text-stone bg-charcoal transition-opacity duration-700 ${immersiveMode ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
        <p>{t.footer}</p>
      </footer>
      
      {/* Immersive Mode Toggle */}
      <button 
        onClick={() => setImmersiveMode(!immersiveMode)}
        className="fixed bottom-8 right-8 z-[100] bg-charcoal/60 backdrop-blur-md p-3 rounded-full border border-white/10 hover:bg-white/10 transition-colors group flex items-center justify-center gap-2"
        title="Toggle Immersive View"
      >
        {immersiveMode ? (
          <>
            <EyeOff className="w-5 h-5 text-warm-white" />
            <span className="text-xs uppercase tracking-widest text-warm-white pr-2 hidden md:block">Return</span>
          </>
        ) : (
          <Eye className="w-5 h-5 text-warm-white" />
        )}
      </button>

      {/* Global overlay for exiting immersive mode */}
      {immersiveMode && (
        <div 
          className="fixed inset-0 z-[90] cursor-pointer" 
          onClick={() => setImmersiveMode(false)}
        />
      )}
    </div>
    </ImmersiveContext.Provider>
  );
}
