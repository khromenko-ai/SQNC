import { Translation, Room } from './types';

const roomsEn: Room[] = [
  {
    id: 'room1',
    number: 1,
    title: 'THE CALL',
    conceptTitle: 'Concept',
    concept: 'Leaving ordinary perception.',
    environmentTitle: 'Environment',
    environment: 'A pure white architectural space. Vertical beams of light pass through thin atmospheric haze.',
    experienceTitle: 'Experience',
    experience: 'The visitor enters a new rhythm.',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2069&auto=format&fit=crop'
  },
  {
    id: 'room2',
    number: 2,
    title: 'INVERSION',
    conceptTitle: 'Concept',
    concept: 'Breaking habitual perception.',
    environmentTitle: 'Environment',
    environment: 'An upside-down tropical garden. Reflective floor. Architecture appears reversed.',
    experienceTitle: 'Experience',
    experience: 'The visitor loses traditional spatial orientation.',
    image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 'room3',
    number: 3,
    title: 'RESISTANCE',
    conceptTitle: 'Concept',
    concept: 'Encounter with the body.',
    environmentTitle: 'Environment',
    environment: 'Dark space. Chiaroscuro lighting. Copal aroma. Performers guide attention through movement and presence.',
    experienceTitle: 'Experience',
    experience: 'The visitor notices internal rhythms.',
    image: 'https://images.unsplash.com/photo-1507676184212-d0330a15233c?q=80&w=2069&auto=format&fit=crop'
  },
  {
    id: 'room4',
    number: 4,
    title: 'INTERFERENCE',
    conceptTitle: 'Concept',
    concept: 'Patterns emerge through overlapping rhythms.',
    environmentTitle: 'Environment',
    environment: 'Moiré structures. Reflective surfaces. Moving light grids.',
    experienceTitle: 'Experience',
    experience: 'The visitor becomes part of changing visual frequencies.',
    image: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 'room5',
    number: 5,
    title: 'THE VOID',
    conceptTitle: 'Concept',
    concept: 'Reduction and silence.',
    environmentTitle: 'Environment',
    environment: 'Minimal golden-hour space.',
    experienceTitle: 'Experience',
    experience: 'After complexity comes simplicity.',
    image: 'https://images.unsplash.com/photo-1505691938895-1758d7feb511?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 'room6',
    number: 6,
    title: 'RESONANCE',
    conceptTitle: 'Concept',
    concept: 'The transformation point.',
    environmentTitle: 'Environment',
    environment: 'Immersive light cocoon. Fractal light patterns. Sound composition. Subtle vibration.',
    experienceTitle: 'Experience',
    experience: 'Individual perception synchronizes with collective rhythm.',
    image: 'https://images.unsplash.com/photo-1518331647614-7a1f04cd34af?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 'room7',
    number: 7,
    title: 'INTEGRATION',
    conceptTitle: 'Concept',
    concept: 'Returning transformed.',
    environmentTitle: 'Environment',
    environment: 'Soft transition between installation and social space.',
    experienceTitle: 'Experience',
    experience: 'The visitor reconnects with the world.',
    image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=2069&auto=format&fit=crop'
  },
  {
    id: 'room8',
    number: 8,
    title: 'RESET BAR',
    conceptTitle: 'Concept',
    concept: 'Conversation after transformation. A sophisticated cultural salon.',
    environmentTitle: 'Environment',
    environment: 'Luxury boutique hotel bar inside historic Mexico City mansion, contemporary art, tropical plants, warm indirect lighting.',
    experienceTitle: 'Experience',
    experience: 'Integration through dialogue.',
    image: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=1974&auto=format&fit=crop'
  }
];

const roomsEs: Room[] = [
  { ...roomsEn[0], title: 'EL LLAMADO', concept: 'Dejando la percepción ordinaria.', environment: 'Un espacio arquitectónico blanco puro. Rayos verticales de luz pasan a través de una fina neblina atmosférica.', experience: 'El visitante entra en un nuevo ritmo.' },
  { ...roomsEn[1], title: 'INVERSIÓN', concept: 'Rompiendo la percepción habitual.', environment: 'Un jardín tropical invertido. Suelo reflectante. La arquitectura aparece invertida.', experience: 'El visitante pierde la orientación espacial tradicional.' },
  { ...roomsEn[2], title: 'RESISTENCIA', concept: 'Encuentro con el cuerpo.', environment: 'Espacio oscuro. Iluminación claroscuro. Aroma a copal. Intérpretes guían la atención a través del movimiento y la presencia.', experience: 'El visitante nota los ritmos internos.' },
  { ...roomsEn[3], title: 'INTERFERENCIA', concept: 'Los patrones emergen a través de ritmos superpuestos.', environment: 'Estructuras moiré. Superficies reflectantes. Rejillas de luz en movimiento.', experience: 'El visitante se convierte en parte de las frecuencias visuales cambiantes.' },
  { ...roomsEn[4], title: 'EL VACÍO', concept: 'Reducción y silencio.', environment: 'Espacio minimalista en la hora dorada.', experience: 'Después de la complejidad viene la simplicidad.' },
  { ...roomsEn[5], title: 'RESONANCIA', concept: 'El punto de transformación.', environment: 'Capullo de luz inmersivo. Patrones de luz fractales. Composición sonora. Vibración sutil.', experience: 'La percepción individual se sincroniza con el ritmo colectivo.' },
  { ...roomsEn[6], title: 'INTEGRACIÓN', concept: 'Regresando transformado.', environment: 'Suave transición entre la instalación y el espacio social.', experience: 'El visitante se reconecta con el mundo.' },
  { ...roomsEn[7], title: 'RESET BAR', concept: 'Conversación después de la transformación. Un sofisticado salón cultural.', environment: 'Bar de hotel boutique de lujo dentro de una histórica mansión de la Ciudad de México.', experience: 'Integración a través del diálogo.' }
];

const roomsRu: Room[] = [
  { ...roomsEn[0], title: 'ЗОВ', concept: 'Оставление обычного восприятия.', environment: 'Чистое белое архитектурное пространство. Вертикальные лучи света проходят сквозь тонкую атмосферную дымку.', experience: 'Посетитель входит в новый ритм.' },
  { ...roomsEn[1], title: 'ПЕРЕВОРОТ', concept: 'Разрушение привычного восприятия.', environment: 'Перевернутый тропический сад. Отражающий пол. Архитектура кажется перевернутой.', experience: 'Посетитель теряет традиционную пространственную ориентацию.' },
  { ...roomsEn[2], title: 'СОПРОТИВЛЕНИЕ', concept: 'Встреча с телом.', environment: 'Темное пространство. Освещение кьяроскуро. Аромат копала. Перформеры направляют внимание через движение и присутствие.', experience: 'Посетитель замечает внутренние ритмы.' },
  { ...roomsEn[3], title: 'ИНТЕРФЕРЕНЦИЯ', concept: 'Узоры возникают через наложение ритмов.', environment: 'Муаровые структуры. Отражающие поверхности. Движущиеся световые сетки.', experience: 'Посетитель становится частью меняющихся визуальных частот.' },
  { ...roomsEn[4], title: 'ПУСТОТА', concept: 'Редукция и тишина.', environment: 'Минималистичное пространство золотого часа.', experience: 'После сложности приходит простота.' },
  { ...roomsEn[5], title: 'РЕЗОНАНС', concept: 'Точка трансформации.', environment: 'Иммерсивный световой кокон. Фрактальные световые узоры. Звуковая композиция. Тонкая вибрация.', experience: 'Индивидуальное восприятие синхронизируется с коллективным ритмом.' },
  { ...roomsEn[6], title: 'ИНТЕГРАЦИЯ', concept: 'Возвращение трансформированным.', environment: 'Мягкий переход между инсталляцией и социальным пространством.', experience: 'Посетитель воссоединяется с миром.' },
  { ...roomsEn[7], title: 'RESET BAR', concept: 'Разговор после трансформации. Изысканный культурный салон.', environment: 'Роскошный бар бутик-отеля в историческом особняке Мехико.', experience: 'Интеграция через диалог.' }
];

export const translations: Record<'en' | 'es' | 'ru', Translation> = {
  en: {
    hero: {
      title: 'SQNC',
      subtitle: 'A journey through rhythm, resonance and perception.',
      description: 'An immersive environment where contemporary art, architecture, light, sound and human presence become one evolving composition.',
      ctaPrimary: 'Reserve the experience',
      ctaSecondary: 'Discover the concept',
    },
    concept: {
      title: 'THE CONCEPT',
      description1: 'SQNC is an immersive evening experience inside a living contemporary art gallery.',
      description2: 'During the day, the mansion functions as a changing exhibition space where artworks continuously evolve through rotating collections of different artists.',
      description3: 'At night, the gallery transforms. The visitor becomes the protagonist of a journey inspired by:',
      journey: [
        "Campbell’s Hero's Journey",
        'Henri Lefebvre’s rhythmanalysis',
        'contemporary performance art',
        'sensory perception research'
      ],
      stages: 'Observer → Participant → Resonant Element'
    },
    livingGallery: {
      title: 'THE LIVING GALLERY',
      dayTitle: 'DAY',
      dayDesc: 'Contemporary art exhibition. Works can be viewed and purchased. A constantly evolving collection.',
      nightTitle: 'NIGHT',
      nightDesc: 'SQNC transforms the same architecture into a living immersive environment.'
    },
    journey: {
      title: 'THE JOURNEY',
      rooms: roomsEn
    },
    booking: {
      title: 'SQNC',
      subtitle: 'A journey through rhythm and resonance.',
      location: 'Mexico City. Condesa.',
      time: 'Evening immersive experience.',
      capacity: 'Limited groups.',
      cta: 'Reserve your journey'
    }
  },
  es: {
    hero: {
      title: 'SQNC',
      subtitle: 'Un viaje a través del ritmo, la resonancia y la percepción.',
      description: 'Un entorno inmersivo donde el arte contemporáneo, la arquitectura, la luz, el sonido y la presencia humana se convierten en una composición en evolución.',
      ctaPrimary: 'Reserva la experiencia',
      ctaSecondary: 'Descubre el concepto',
    },
    concept: {
      title: 'EL CONCEPTO',
      description1: 'SQNC es una experiencia inmersiva nocturna dentro de una galería de arte contemporáneo viva.',
      description2: 'Durante el día, la mansión funciona como un espacio de exposición cambiante donde las obras de arte evolucionan continuamente a través de colecciones rotativas de diferentes artistas.',
      description3: 'Por la noche, la galería se transforma. El visitante se convierte en el protagonista de un viaje inspirado en:',
      journey: [
        "El Viaje del Héroe de Campbell",
        'El ritoanálisis de Henri Lefebvre',
        'El arte de performance contemporáneo',
        'La investigación de la percepción sensorial'
      ],
      stages: 'Observador → Participante → Elemento Resonante'
    },
    livingGallery: {
      title: 'LA GALERÍA VIVA',
      dayTitle: 'DÍA',
      dayDesc: 'Exposición de arte contemporáneo. Las obras pueden ser vistas y compradas. Una colección en constante evolución.',
      nightTitle: 'NOCHE',
      nightDesc: 'SQNC transforma la misma arquitectura en un entorno inmersivo vivo.'
    },
    journey: {
      title: 'EL VIAJE',
      rooms: roomsEs
    },
    booking: {
      title: 'SQNC',
      subtitle: 'Un viaje a través del ritmo y la resonancia.',
      location: 'Ciudad de México. Condesa.',
      time: 'Experiencia inmersiva nocturna.',
      capacity: 'Grupos limitados.',
      cta: 'Reserva tu viaje'
    }
  },
  ru: {
    hero: {
      title: 'SQNC',
      subtitle: 'Путь через ритм, резонанс и восприятие.',
      description: 'Иммерсивная среда, где современное искусство, архитектура, свет, звук и человеческое присутствие становятся единой развивающейся композицией.',
      ctaPrimary: 'Забронировать опыт',
      ctaSecondary: 'Узнать концепцию',
    },
    concept: {
      title: 'КОНЦЕПЦИЯ',
      description1: 'SQNC — это вечерний иммерсивный опыт внутри живой галереи современного искусства.',
      description2: 'Днем особняк функционирует как меняющееся выставочное пространство, где произведения искусства постоянно развиваются через сменяющиеся коллекции разных художников.',
      description3: 'Ночью галерея трансформируется. Посетитель становится главным героем путешествия, вдохновленного:',
      journey: [
        "Путь Героя Кэмпбелла",
        'Ритманализ Анри Лефевра',
        'Современный перформанс',
        'Исследования сенсорного восприятия'
      ],
      stages: 'Наблюдатель → Участник → Резонирующий Элемент'
    },
    livingGallery: {
      title: 'ЖИВАЯ ГАЛЕРЕЯ',
      dayTitle: 'ДЕНЬ',
      dayDesc: 'Выставка современного искусства. Работы можно посмотреть и приобрести. Постоянно развивающаяся коллекция.',
      nightTitle: 'НОЧЬ',
      nightDesc: 'SQNC превращает ту же архитектуру в живую иммерсивную среду.'
    },
    journey: {
      title: 'ПУТЬ',
      rooms: roomsRu
    },
    booking: {
      title: 'SQNC',
      subtitle: 'Путь через ритм и резонанс.',
      location: 'Мехико. Кондеса.',
      time: 'Вечерний иммерсивный опыт.',
      capacity: 'Ограниченные группы.',
      cta: 'Забронируйте свое путешествие'
    }
  }
};
