export const translations = {
  en: {
    navSubtitle: "Investment Proposal",
    heroSubtitle: "A sensory immersive exhibition on the rhythm of perception",
    heroLocation: "Hipódromo Condesa, Mexico City",
    conceptTitle: "Project Concept",
    conceptDesc1: "SQNC CDMX is a new format of cultural experience at the intersection of contemporary art, performance and architecture.",
    conceptDesc2: "Located in a historic 1920s–1930s building in the Hipódromo Condesa neighbourhood, SQNC is neither a traditional exhibition nor a conventional show. It is a sequence of carefully designed sensory environments that gently transform the visitor's perceptual state through light, sound, movement, materials and space.",
    conceptDesc3: "The project is built on the idea of rhythm as a fundamental mechanism of perception. Each room represents a different dynamic state — from simple oscillation to more complex forms of resonance, interference and the emergence of new patterns.",
    conceptSubtitle: "The visitor moves through subtle layers of experience:",
    conceptList: ['sound', 'vibration', 'movement', 'breathing', 'spatial orientation', 'interaction with architecture'],
    conceptQuote: "SQNC does not explore the artwork as a fixed object, but the moment when perception itself begins to change.",
    
    formatTitle: "Experience Format",
    formatDesc1: "SQNC does not rely on extreme effects or virtual entertainment.",
    formatDesc2: "The project uses precise, human elements:",
    formatList: ['live performance', 'lighting design', 'acoustic design', 'natural materials', 'objects', 'architecture', 'dynamic reconfiguration of the exhibition'],
    formatDesc3: "The exhibition functions as a living system: the space can subtly modify its configuration, reveal new relationships between the works and create the sensation of a unique moment of presence. Every visitor becomes a witness to a transformation.",
    
    visitorTitle: "Visitor Experience",
    visitorStats: [
      { label: 'Groups', value: 'up to 12 people' },
      { label: 'Duration', value: '75–90 minutes' },
      { label: 'Sessions', value: 'limited number per day' },
      { label: 'Level', value: 'premium cultural experience' }
    ],
    visitorProgression: "Progression of perceptual states",
    visitorStates: [
      { title: 'Oscillation', desc: 'establishing the fundamental rhythm' },
      { title: 'Deviation', desc: 'gentle departure from habitual perception' },
      { title: 'Fluctuation', desc: 'expanding sensitivity through variation' },
      { title: 'Interference', desc: 'superposition of signals and rising complexity' },
      { title: 'Resonance', desc: 'synchronisation between body and environment' },
      { title: 'Phase Shift', desc: 'transition toward a new perceptual mode' },
      { title: 'Strange Attractor', desc: 'appearance of complex order' },
      { title: 'Emergence', desc: 'integration and return' },
    ],
    visitorQuote: "SQNC is neither therapy nor entertainment. It is a brief recalibration of everyday perception: a controlled departure from habitual patterns of attention and a return with a renewed sense of presence.",
    
    valueTitle: "Strategic Value for the Owner",
    valueDesc1: "The historic building holds great architectural and cultural value, yet its potential as a public destination is not fully developed.",
    valueDesc2: "SQNC turns the property into a new cultural asset:",
    valueList: [
      'generates a steady flow of visitors',
      'increases the building\'s visibility',
      'strengthens neighbourhood identity',
      'creates a new revenue stream',
      'builds an audience for future hospitality projects'
    ],
    valueQuote: "SQNC can become a signature cultural experience of the property — comparable to a destination restaurant, a spa or a distinctive architectural feature within a hotel ecosystem.",
    
    capexTitle: "Initial Investment (CAPEX)",
    capexCategory: "Category",
    capexEstimate: "Estimate",
    capexRows: [
      { cat: 'Artistic concept & direction', est: '$25–40k' },
      { cat: 'Performers & stage production', est: '$15–30k' },
      { cat: 'Objects, props & materials', est: '$15–25k' },
      { cat: 'Lighting design & installation', est: '$20–35k' },
      { cat: 'Sound & acoustics', est: '$10–20k' },
      { cat: 'Furniture, textiles & spatial design', est: '$15–30k' },
      { cat: 'Technical fit-out & installation', est: '$15–25k' },
      { cat: 'Branding, website & ticketing', est: '$20–35k' },
      { cat: 'Launch campaign & PR', est: '$20–40k' },
    ],
    capexTotal: "Estimated total launch budget:",
    capexTotalValue: "≈ $165–300k",
    
    opexTitle: "Operating Model",
    opexCategory: "Category",
    opexEstimate: "Monthly estimate",
    opexRows: [
      { cat: 'Staff & performers', est: '$15–25k' },
      { cat: 'Marketing', est: '$8–15k' },
      { cat: 'Technical maintenance', est: '$5–10k' },
      { cat: 'Administration', est: '~$5k' },
    ],
    opexTotal: "Total monthly OPEX:",
    opexTotalValue: "≈ $30–50k",
    
    revenueTitle: "Revenue Model",
    revenueTicket: "Ticket programme",
    revenueTicketValue: "$50–70 USD",
    revenuePrivate: "Private Experience",
    revenuePrivateDesc: "Exclusive session for up to 12 people",
    revenuePrivateValue: "$900–1,500 USD",
    revenueCorp: "Corporate / hospitality events",
    revenueCorpDesc: "Tailored experiences",
    revenueCorpValue: "$1,500–3,000 USD",
    
    potentialTitle: "Revenue Potential",
    potentialCons: "Conservative scenario",
    potentialConsDesc: "5 daily sessions · 70% occupancy",
    potentialConsValue: "≈ $65k/month",
    potentialBase: "Base scenario",
    potentialBaseDesc: "6 daily sessions · 85% occupancy",
    potentialBaseValue: "≈ $110–120k/month",
    potentialAdd: "Additional revenue",
    potentialAddList: ['private events', 'corporate experiences', 'bar activation', 'brand collaborations'],
    potentialTotal: "Potential monthly revenue:",
    potentialTotalValue: "$80–140k",
    
    roiTitle: "Return on Investment",
    roiNoSponsors: "Without sponsors",
    roiInvest: "Initial investment",
    roiInvestValue1: "≈ $200k",
    roiProfit: "Estimated operating profit",
    roiProfitValue: "≈ $40–60k/month",
    roiPayback: "Payback period",
    roiPaybackValue: "4–8 months after stable occupancy",
    roiSponsors: "With a strategic partner",
    roiOwnerInvest: "Owner's investment",
    roiOwnerInvestValue: "significantly reduced",
    roiPath: "Path to profitability",
    roiPathValue: "2–4 months after opening",
    
    sponsorsTitle: "Sponsorship Opportunities",
    sponsorsTiers: [
      {
        title: 'Project Principal Partner',
        target: 'banks · telecoms · technology brands',
        value: '$150–300k',
        items: ['principal association with SQNC', 'brand presence in communication', 'private client experiences', 'corporate events']
      },
      {
        title: 'Final Bar Partner',
        target: 'premium beverage brands · distilleries',
        value: '$50–100k',
        items: ['natural integration into the space', 'signature cocktail creation', 'associated hospitality zone', 'private events']
      },
      {
        title: 'Media Partner',
        target: 'media & content platforms',
        value: '$30–80k',
        items: ['exclusive access to content', 'launch coverage', 'interviews & visual storytelling', 'cultural positioning']
      }
    ],
    
    whynowTitle: "Why SQNC Now",
    whynowDesc1: "Mexico City is consolidating its position as one of the world's leading centres of contemporary culture, design, gastronomy and creative industries.",
    whynowDesc2: "SQNC creates a new category of destination:",
    whynowList: ['not a museum', 'not a theatre', 'not a restaurant', 'not a wellness centre'],
    whynowDesc3: "It is a place where architecture, art and perception come together to create a unique experience.",
    whynowQuote: "SQNC CDMX is an opportunity to transform a historic building into a living platform for the future of cultural experiences.",
    
    footer: "© 2026 SQNC CDMX. All rights reserved."
  },
  es: {
    navSubtitle: "Propuesta de Inversión",
    heroSubtitle: "Una exhibición inmersiva sensorial sobre el ritmo de la percepción",
    heroLocation: "Hipódromo Condesa, Ciudad de México",
    conceptTitle: "Concepto del Proyecto",
    conceptDesc1: "SQNC CDMX es un nuevo formato de experiencia cultural en la intersección del arte contemporáneo, el performance y la arquitectura.",
    conceptDesc2: "Ubicado en un edificio histórico de 1920-1930 en la colonia Hipódromo Condesa, SQNC no es una exhibición tradicional ni un espectáculo convencional. Es una secuencia de entornos sensoriales cuidadosamente diseñados que transforman suavemente el estado perceptivo del visitante a través de la luz, el sonido, el movimiento, los materiales y el espacio.",
    conceptDesc3: "El proyecto se basa en la idea del ritmo como mecanismo fundamental de la percepción. Cada sala representa un estado dinámico diferente: desde la simple oscilación hasta formas más complejas de resonancia, interferencia y el surgimiento de nuevos patrones.",
    conceptSubtitle: "El visitante se mueve a través de sutiles capas de experiencia:",
    conceptList: ['sonido', 'vibración', 'movimiento', 'respiración', 'orientación espacial', 'interacción con la arquitectura'],
    conceptQuote: "SQNC no explora la obra de arte como un objeto fijo, sino el momento en que la percepción misma comienza a cambiar.",
    
    formatTitle: "Formato de Experiencia",
    formatDesc1: "SQNC no se basa en efectos extremos o entretenimiento virtual.",
    formatDesc2: "El proyecto utiliza elementos precisos y humanos:",
    formatList: ['performance en vivo', 'diseño de iluminación', 'diseño acústico', 'materiales naturales', 'objetos', 'arquitectura', 'reconfiguración dinámica de la exhibición'],
    formatDesc3: "La exhibición funciona como un sistema vivo: el espacio puede modificar sutilmente su configuración, revelar nuevas relaciones entre las obras y crear la sensación de un momento único de presencia. Cada visitante se convierte en testigo de una transformación.",
    
    visitorTitle: "Experiencia del Visitante",
    visitorStats: [
      { label: 'Grupos', value: 'hasta 12 personas' },
      { label: 'Duración', value: '75–90 minutos' },
      { label: 'Sesiones', value: 'número limitado por día' },
      { label: 'Nivel', value: 'experiencia cultural premium' }
    ],
    visitorProgression: "Progresión de estados perceptivos",
    visitorStates: [
      { title: 'Oscilación', desc: 'estableciendo el ritmo fundamental' },
      { title: 'Desviación', desc: 'suave alejamiento de la percepción habitual' },
      { title: 'Fluctuación', desc: 'expandiendo la sensibilidad a través de la variación' },
      { title: 'Interferencia', desc: 'superposición de señales y complejidad creciente' },
      { title: 'Resonancia', desc: 'sincronización entre cuerpo y entorno' },
      { title: 'Cambio de Fase', desc: 'transición hacia un nuevo modo perceptivo' },
      { title: 'Atractor Extraño', desc: 'aparición de un orden complejo' },
      { title: 'Emergencia', desc: 'integración y retorno' },
    ],
    visitorQuote: "SQNC no es terapia ni entretenimiento. Es una breve recalibración de la percepción cotidiana: un alejamiento controlado de los patrones habituales de atención y un retorno con un renovado sentido de presencia.",
    
    valueTitle: "Valor Estratégico para el Propietario",
    valueDesc1: "El edificio histórico tiene un gran valor arquitectónico y cultural, sin embargo, su potencial como destino público no está completamente desarrollado.",
    valueDesc2: "SQNC convierte la propiedad en un nuevo activo cultural:",
    valueList: [
      'genera un flujo constante de visitantes',
      'aumenta la visibilidad del edificio',
      'fortalece la identidad del barrio',
      'crea una nueva fuente de ingresos',
      'construye una audiencia para futuros proyectos de hospitalidad'
    ],
    valueQuote: "SQNC puede convertirse en una experiencia cultural distintiva de la propiedad, comparable a un restaurante de destino, un spa o una característica arquitectónica única dentro de un ecosistema hotelero.",
    
    capexTitle: "Inversión Inicial (CAPEX)",
    capexCategory: "Categoría",
    capexEstimate: "Estimado",
    capexRows: [
      { cat: 'Concepto y dirección artística', est: '$25–40k' },
      { cat: 'Artistas y producción escénica', est: '$15–30k' },
      { cat: 'Objetos, utilería y materiales', est: '$15–25k' },
      { cat: 'Diseño e instalación de iluminación', est: '$20–35k' },
      { cat: 'Sonido y acústica', est: '$10–20k' },
      { cat: 'Mobiliario, textiles y diseño espacial', est: '$15–30k' },
      { cat: 'Acondicionamiento técnico e instalación', est: '$15–25k' },
      { cat: 'Branding, sitio web y boletaje', est: '$20–35k' },
      { cat: 'Campaña de lanzamiento y RRPP', est: '$20–40k' },
    ],
    capexTotal: "Presupuesto total estimado de lanzamiento:",
    capexTotalValue: "≈ $165–300k",
    
    opexTitle: "Modelo Operativo",
    opexCategory: "Categoría",
    opexEstimate: "Estimado mensual",
    opexRows: [
      { cat: 'Personal y artistas', est: '$15–25k' },
      { cat: 'Marketing', est: '$8–15k' },
      { cat: 'Mantenimiento técnico', est: '$5–10k' },
      { cat: 'Administración', est: '~$5k' },
    ],
    opexTotal: "OPEX total mensual:",
    opexTotalValue: "≈ $30–50k",
    
    revenueTitle: "Modelo de Ingresos",
    revenueTicket: "Programa de boletos",
    revenueTicketValue: "$50–70 USD",
    revenuePrivate: "Experiencia Privada",
    revenuePrivateDesc: "Sesión exclusiva para hasta 12 personas",
    revenuePrivateValue: "$900–1,500 USD",
    revenueCorp: "Eventos corporativos / hospitalidad",
    revenueCorpDesc: "Experiencias a la medida",
    revenueCorpValue: "$1,500–3,000 USD",
    
    potentialTitle: "Potencial de Ingresos",
    potentialCons: "Escenario conservador",
    potentialConsDesc: "5 sesiones diarias · 70% ocupación",
    potentialConsValue: "≈ $65k/mes",
    potentialBase: "Escenario base",
    potentialBaseDesc: "6 sesiones diarias · 85% ocupación",
    potentialBaseValue: "≈ $110–120k/mes",
    potentialAdd: "Ingresos adicionales",
    potentialAddList: ['eventos privados', 'experiencias corporativas', 'activación de bar', 'colaboraciones de marca'],
    potentialTotal: "Ingreso mensual potencial:",
    potentialTotalValue: "$80–140k",
    
    roiTitle: "Retorno de Inversión",
    roiNoSponsors: "Sin patrocinadores",
    roiInvest: "Inversión inicial",
    roiInvestValue1: "≈ $200k",
    roiProfit: "Beneficio operativo estimado",
    roiProfitValue: "≈ $40–60k/mes",
    roiPayback: "Periodo de recuperación",
    roiPaybackValue: "4–8 meses después de ocupación estable",
    roiSponsors: "Con un socio estratégico",
    roiOwnerInvest: "Inversión del propietario",
    roiOwnerInvestValue: "significativamente reducida",
    roiPath: "Camino a la rentabilidad",
    roiPathValue: "2–4 meses después de la apertura",
    
    sponsorsTitle: "Oportunidades de Patrocinio",
    sponsorsTiers: [
      {
        title: 'Socio Principal del Proyecto',
        target: 'bancos · telecomunicaciones · marcas de tecnología',
        value: '$150–300k',
        items: ['asociación principal con SQNC', 'presencia de marca en comunicación', 'experiencias para clientes privados', 'eventos corporativos']
      },
      {
        title: 'Socio Final de Bar',
        target: 'marcas de bebidas premium · destilerías',
        value: '$50–100k',
        items: ['integración natural en el espacio', 'creación de cócteles exclusivos', 'zona de hospitalidad asociada', 'eventos privados']
      },
      {
        title: 'Socio de Medios',
        target: 'plataformas de medios y contenido',
        value: '$30–80k',
        items: ['acceso exclusivo a contenido', 'cobertura de lanzamiento', 'entrevistas y narrativa visual', 'posicionamiento cultural']
      }
    ],
    
    whynowTitle: "Por qué SQNC Ahora",
    whynowDesc1: "La Ciudad de México está consolidando su posición como uno de los principales centros mundiales de cultura contemporánea, diseño, gastronomía e industrias creativas.",
    whynowDesc2: "SQNC crea una nueva categoría de destino:",
    whynowList: ['no es un museo', 'no es un teatro', 'no es un restaurante', 'no es un centro de bienestar'],
    whynowDesc3: "Es un lugar donde la arquitectura, el arte y la percepción se unen para crear una experiencia única.",
    whynowQuote: "SQNC CDMX es una oportunidad para transformar un edificio histórico en una plataforma viva para el futuro de las experiencias culturales.",
    
    footer: "© 2026 SQNC CDMX. Todos los derechos reservados."
  },
  ru: {
    navSubtitle: "Инвестиционное предложение",
    heroSubtitle: "Сенсорная иммерсивная выставка о ритмах восприятия",
    heroLocation: "Иподромо Кондеса, Мехико",
    conceptTitle: "Концепция проекта",
    conceptDesc1: "SQNC CDMX — это новый формат культурного опыта на стыке современного искусства, перформанса и архитектуры.",
    conceptDesc2: "Расположенный в историческом здании 1920–1930-х годов в районе Иподромо Кондеса, SQNC не является ни традиционной выставкой, ни обычным шоу. Это последовательность тщательно продуманных сенсорных пространств, которые мягко трансформируют состояние восприятия посетителя через свет, звук, движение, материалы и пространство.",
    conceptDesc3: "Проект построен на идее ритма как фундаментального механизма восприятия. Каждая комната представляет собой различное динамическое состояние — от простой осцилляции до более сложных форм резонанса, интерференции и возникновения новых паттернов.",
    conceptSubtitle: "Посетитель проходит через тонкие уровни опыта:",
    conceptList: ['звук', 'вибрация', 'движение', 'дыхание', 'пространственная ориентация', 'взаимодействие с архитектурой'],
    conceptQuote: "SQNC исследует произведение искусства не как фиксированный объект, а как момент, когда само восприятие начинает меняться.",
    
    formatTitle: "Формат опыта",
    formatDesc1: "SQNC не опирается на экстремальные эффекты или виртуальные развлечения.",
    formatDesc2: "В проекте используются точные, человеческие элементы:",
    formatList: ['живой перформанс', 'световой дизайн', 'акустический дизайн', 'натуральные материалы', 'объекты', 'архитектура', 'динамическая реконфигурация выставки'],
    formatDesc3: "Выставка функционирует как живая система: пространство может незаметно менять свою конфигурацию, раскрывать новые связи между работами и создавать ощущение уникального момента присутствия. Каждый посетитель становится свидетелем трансформации.",
    
    visitorTitle: "Опыт посетителя",
    visitorStats: [
      { label: 'Группы', value: 'до 12 человек' },
      { label: 'Продолжительность', value: '75–90 минут' },
      { label: 'Сеансы', value: 'ограниченное количество в день' },
      { label: 'Уровень', value: 'премиальный культурный опыт' }
    ],
    visitorProgression: "Развитие состояний восприятия",
    visitorStates: [
      { title: 'Осцилляция', desc: 'установление фундаментального ритма' },
      { title: 'Отклонение', desc: 'мягкий отход от привычного восприятия' },
      { title: 'Флуктуация', desc: 'расширение чувствительности через вариации' },
      { title: 'Интерференция', desc: 'наложение сигналов и возрастающая сложность' },
      { title: 'Резонанс', desc: 'синхронизация между телом и средой' },
      { title: 'Сдвиг фазы', desc: 'переход к новому режиму восприятия' },
      { title: 'Странный аттрактор', desc: 'появление сложного порядка' },
      { title: 'Эмерджентность', desc: 'интеграция и возвращение' },
    ],
    visitorQuote: "SQNC — это не терапия и не развлечение. Это краткая перекалибровка повседневного восприятия: контролируемый отход от привычных паттернов внимания и возвращение с обновленным чувством присутствия.",
    
    valueTitle: "Стратегическая ценность для владельца",
    valueDesc1: "Историческое здание имеет огромную архитектурную и культурную ценность, однако его потенциал как общественного места назначения не раскрыт полностью.",
    valueDesc2: "SQNC превращает недвижимость в новый культурный актив:",
    valueList: [
      'генерирует постоянный поток посетителей',
      'повышает узнаваемость здания',
      'укрепляет идентичность района',
      'создает новый источник дохода',
      'формирует аудиторию для будущих проектов гостеприимства'
    ],
    valueQuote: "SQNC может стать фирменным культурным опытом объекта — сопоставимым с популярным рестораном, спа или отличительной архитектурной особенностью в экосистеме отеля.",
    
    capexTitle: "Первоначальные инвестиции (CAPEX)",
    capexCategory: "Категория",
    capexEstimate: "Оценка",
    capexRows: [
      { cat: 'Художественная концепция и режиссура', est: '$25–40k' },
      { cat: 'Перформеры и сценическое производство', est: '$15–30k' },
      { cat: 'Объекты, реквизит и материалы', est: '$15–25k' },
      { cat: 'Световой дизайн и монтаж', est: '$20–35k' },
      { cat: 'Звук и акустика', est: '$10–20k' },
      { cat: 'Мебель, текстиль и дизайн пространства', est: '$15–30k' },
      { cat: 'Техническое оснащение и установка', est: '$15–25k' },
      { cat: 'Брендинг, сайт и продажа билетов', est: '$20–35k' },
      { cat: 'Кампания запуска и PR', est: '$20–40k' },
    ],
    capexTotal: "Ориентировочный общий бюджет запуска:",
    capexTotalValue: "≈ $165–300k",
    
    opexTitle: "Операционная модель",
    opexCategory: "Категория",
    opexEstimate: "Ежемесячная оценка",
    opexRows: [
      { cat: 'Персонал и артисты', est: '$15–25k' },
      { cat: 'Маркетинг', est: '$8–15k' },
      { cat: 'Техническое обслуживание', est: '$5–10k' },
      { cat: 'Администрирование', est: '~$5k' },
    ],
    opexTotal: "Общие ежемесячные операционные расходы:",
    opexTotalValue: "≈ $30–50k",
    
    revenueTitle: "Модель доходов",
    revenueTicket: "Продажа билетов",
    revenueTicketValue: "$50–70 USD",
    revenuePrivate: "Частный опыт",
    revenuePrivateDesc: "Эксклюзивный сеанс до 12 человек",
    revenuePrivateValue: "$900–1,500 USD",
    revenueCorp: "Корпоративные / гостиничные мероприятия",
    revenueCorpDesc: "Индивидуальные программы",
    revenueCorpValue: "$1,500–3,000 USD",
    
    potentialTitle: "Потенциал дохода",
    potentialCons: "Консервативный сценарий",
    potentialConsDesc: "5 сеансов в день · 70% заполняемость",
    potentialConsValue: "≈ $65k/месяц",
    potentialBase: "Базовый сценарий",
    potentialBaseDesc: "6 сеансов в день · 85% заполняемость",
    potentialBaseValue: "≈ $110–120k/месяц",
    potentialAdd: "Дополнительный доход",
    potentialAddList: ['частные мероприятия', 'корпоративные события', 'активация бара', 'сотрудничество с брендами'],
    potentialTotal: "Потенциальный ежемесячный доход:",
    potentialTotalValue: "$80–140k",
    
    roiTitle: "Рентабельность инвестиций (ROI)",
    roiNoSponsors: "Без спонсоров",
    roiInvest: "Первоначальные инвестиции",
    roiInvestValue1: "≈ $200k",
    roiProfit: "Оценочная операционная прибыль",
    roiProfitValue: "≈ $40–60k/месяц",
    roiPayback: "Срок окупаемости",
    roiPaybackValue: "4–8 месяцев после стабильной заполняемости",
    roiSponsors: "Со стратегическим партнером",
    roiOwnerInvest: "Инвестиции владельца",
    roiOwnerInvestValue: "значительно снижены",
    roiPath: "Выход на прибыльность",
    roiPathValue: "через 2–4 месяца после открытия",
    
    sponsorsTitle: "Возможности спонсорства",
    sponsorsTiers: [
      {
        title: 'Главный партнер проекта',
        target: 'банки · телеком · технологические бренды',
        value: '$150–300k',
        items: ['главная ассоциация с SQNC', 'присутствие бренда в коммуникациях', 'частные клиентские мероприятия', 'корпоративные события']
      },
      {
        title: 'Барный партнер',
        target: 'премиальные бренды напитков · винокурни',
        value: '$50–100k',
        items: ['естественная интеграция в пространство', 'создание фирменного коктейля', 'ассоциированная зона гостеприимства', 'частные мероприятия']
      },
      {
        title: 'Медиа-партнер',
        target: 'медиа и контент-платформы',
        value: '$30–80k',
        items: ['эксклюзивный доступ к контенту', 'освещение запуска', 'интервью и визуальный сторителлинг', 'культурное позиционирование']
      }
    ],
    
    whynowTitle: "Почему SQNC именно сейчас",
    whynowDesc1: "Мехико укрепляет свои позиции как один из ведущих мировых центров современной культуры, дизайна, гастрономии и креативных индустрий.",
    whynowDesc2: "SQNC создает новую категорию направления:",
    whynowList: ['не музей', 'не театр', 'не ресторан', 'не оздоровительный центр'],
    whynowDesc3: "Это место, где архитектура, искусство и восприятие сливаются воедино для создания уникального опыта.",
    whynowQuote: "SQNC CDMX — это возможность превратить историческое здание в живую платформу для будущего культурных событий.",
    
    footer: "© 2026 SQNC CDMX. Все права защищены."
  }
}
export type Language = 'en' | 'es' | 'ru';
