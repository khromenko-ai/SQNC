export type Language = 'en' | 'es' | 'ru';

export interface Translation {
  hero: {
    title: string;
    subtitle: string;
    description: string;
    ctaPrimary: string;
    ctaSecondary: string;
  };
  concept: {
    title: string;
    description1: string;
    description2: string;
    description3: string;
    journey: string[];
    stages: string;
  };
  livingGallery: {
    title: string;
    dayTitle: string;
    dayDesc: string;
    nightTitle: string;
    nightDesc: string;
  };
  journey: {
    title: string;
    rooms: Room[];
  };
  booking: {
    title: string;
    subtitle: string;
    location: string;
    time: string;
    capacity: string;
    cta: string;
  };
}

export interface Room {
  id: string;
  number: number;
  title: string;
  conceptTitle: string;
  concept: string;
  environmentTitle: string;
  environment: string;
  experienceTitle: string;
  experience: string;
  image: string;
}
