# SQNC - Immersive Presentation App

Interactive presentation deck for SQNC built with React, Vite, Tailwind CSS, and Motion.

## Development

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
```

The build outputs static assets to `dist/`.
